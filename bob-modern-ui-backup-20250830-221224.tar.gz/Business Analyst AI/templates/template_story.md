
# Story Template

**ID:** STO-XXXX  
**Epic:** EPC-XXXX  
**Related Requirements:** REQ-XXXX  

## Title
One-line summary.

## Description
Detailed explanation.

## Acceptance Criteria
- [ ] AC1
- [ ] AC2

## Notes
Include history & rationale here.
