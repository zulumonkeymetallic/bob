
# Defect Template

**ID:** DEF-XXXX  
**Related Requirement/Story:** REQ-XXXX / STO-XXXX  

## Summary
Short description.

## Steps to Reproduce
1. Step 1
2. Step 2

## Expected Result
...

## Actual Result
...

## Notes
History & rationale here.
