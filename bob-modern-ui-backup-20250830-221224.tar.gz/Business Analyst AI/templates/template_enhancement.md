
# Enhancement Template

**ID:** ENH-XXXX  
**Related Requirement/Story:** REQ-XXXX / STO-XXXX  

## Summary
Short description.

## Description
Detailed explanation.

## Acceptance Criteria
- [ ] AC1
- [ ] AC2

## Notes
History & rationale here.
