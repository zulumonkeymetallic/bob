import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { getStorage } from 'firebase/storage';
import { getFunctions } from 'firebase/functions';

const firebaseConfig = {
  projectId: "bob20250810",
  appId: "1:944624475821:web:95c596038cb9ebdf7df024",
  storageBucket: "bob20250810.appspot.com",
  apiKey: "AIzaSyDsuR1TNHUE74awnbFaU5cA0FGya0voVFk",
  authDomain: "bob20250810.firebaseapp.com",
  messagingSenderId: "944624475821",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);
const storage = getStorage(app);
const functions = getFunctions(app);

export { db, auth, storage, functions, firebaseConfig };
