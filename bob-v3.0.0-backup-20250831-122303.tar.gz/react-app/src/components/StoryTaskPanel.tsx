import React from 'react';

const StoryTaskPanel: React.FC = () => {
  return (
    <div>
      <h3>Story Task Panel</h3>
      <p>Story task management panel coming soon...</p>
    </div>
  );
};

export default StoryTaskPanel;
export {};
