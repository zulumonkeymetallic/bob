import React from 'react';
import { Container } from 'react-bootstrap';

const SprintAdmin: React.FC = () => {
  return (
    <Container className="mt-4">
      <h2>Sprint Administration</h2>
      <p>Sprint management features coming soon...</p>
    </Container>
  );
};

export default SprintAdmin;

export {};
