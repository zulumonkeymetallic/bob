
# Test Case Template

**ID:** TST-XXXX  
**Related Requirement/Defect/Story:** REQ-XXXX / DEF-XXXX / STO-XXXX  

## Title
Short name.

## Preconditions
Setup required.

## Steps
1. Step 1
2. Step 2

## Expected Result
...

## Notes
History & rationale here.
