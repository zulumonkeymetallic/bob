---
description: 'Description of the custom chat mode.'
tools: []
---
Define the purpose of this chat mode and how AI should behave: response style, available tools, focus areas, and any mode-specific instructions or constraints.